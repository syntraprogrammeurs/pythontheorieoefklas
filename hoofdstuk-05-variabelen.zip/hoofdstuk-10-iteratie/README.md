<!-- gemaakt met gereedschap/theorie-uitpakken.py uit de cursusmap pythonbasis -->
# Hoofdstuk 10 — Iteratie: `while`, `for`, `range`, `break` en `continue`

De code uit hoofdstuk 10 van *Python basis — theoriebundel*, genummerd zoals in de bundel.

## Voorbeelden uit de uitleg

| Paragraaf | Bestand | Opmerking |
|---|---|---|
| 10.2 De while-lus | `10.02a-de-while-lus.py` |  |
| 10.2 De while-lus — Een lus die op invoer wacht | `10.02b-een-lus-die-op-invoer-wacht.py` | vraagt invoer |
| 10.2 De while-lus — Een lus die op invoer wacht | `10.02c-een-lus-die-op-invoer-wacht.py` | vraagt invoer |
| 10.3 De for-lus | `10.03a-de-for-lus.py` |  |
| 10.3 De for-lus | `10.03b-de-for-lus.py` |  |
| 10.4 range: tellen zonder lijst | `10.04a-range-tellen-zonder-lijst.py` |  |
| 10.4 range: tellen zonder lijst | `10.04b-range-tellen-zonder-lijst.py` |  |
| 10.5 enumerate en zip | `10.05a-enumerate-en-zip.py` |  |
| 10.5 enumerate en zip | `10.05b-enumerate-en-zip.py` |  |
| 10.5 enumerate en zip | `10.05c-enumerate-en-zip.py` |  |
| 10.6 break en continue | `10.06-break-en-continue.py` |  |
| 10.7 else bij een lus | `10.07-else-bij-een-lus.py` |  |
| 10.8 De patronen die je constant nodig hebt — Optellen | `10.08a-optellen.py` |  |
| 10.8 De patronen die je constant nodig hebt — Tellen met een voorwaarde | `10.08b-tellen-met-een-voorwaarde.py` |  |
| 10.8 De patronen die je constant nodig hebt — Het grootste zoeken | `10.08c-het-grootste-zoeken.py` |  |
| 10.8 De patronen die je constant nodig hebt — Bouwen tijdens het lopen | `10.08d-bouwen-tijdens-het-lopen.py` |  |
| 10.9 Het raadspel | `10.09a-het-raadspel.py` |  |
| 10.9 Het raadspel | `10.09b-het-raadspel.py` | vraagt invoer |

## Klassikale oefeningen

| Oefening | Map | Bestanden |
|---|---|---|
| 10.1 — De leesstatistiek van het jaar | [10.10-klassikale-oefening-10.1-de-leesstatistiek-van-het-jaar](10.10-klassikale-oefening-10.1-de-leesstatistiek-van-het-jaar/) | `opgave.py`, `uitwerking-a.py`, `uitwerking-b-wat-je-in-de-praktijk-zou.py` |
| 10.2 — De boetes van de club | [10.11-klassikale-oefening-10.2-de-boetes-van-de-club](10.11-klassikale-oefening-10.2-de-boetes-van-de-club/) | `uitwerking.py` |

## Commando's uit de uitleg

**10.14 Wat je nu kunt**

```bash
git add main.py
git commit -m "Bouw het raadspel en de leesstatistiek met lussen"
git push
```
