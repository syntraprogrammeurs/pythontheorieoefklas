# Python basis — theoriebundel
# Hoofdstuk 10 — Iteratie: while, for, range, break en continue
# 10.2 De while-lus

teller = 1

while teller <= 5:
    print(f"Ronde {teller}")
    teller += 1

print("Klaar")


# Verwachte uitvoer:
# Ronde 1
# Ronde 2
# Ronde 3
# Ronde 4
# Ronde 5
# Klaar
