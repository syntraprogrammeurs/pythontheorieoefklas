# Python basis — theoriebundel
# Hoofdstuk 10 — Iteratie: while, for, range, break en continue
# 10.3 De for-lus

leden = ["Anke", "Bram", "Cato"]

for lid in leden:
    print(f"Dag {lid}")


# Verwachte uitvoer:
# Dag Anke
# Dag Bram
# Dag Cato
