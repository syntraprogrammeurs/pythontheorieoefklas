# Python basis — theoriebundel
# Hoofdstuk 10 — Iteratie: while, for, range, break en continue
# 10.3 De for-lus
#
# Een for werkt op alles wat je kunt doorlopen:

for teken in "Gent":
    print(teken)


# Verwachte uitvoer:
# G
# e
# n
# t
