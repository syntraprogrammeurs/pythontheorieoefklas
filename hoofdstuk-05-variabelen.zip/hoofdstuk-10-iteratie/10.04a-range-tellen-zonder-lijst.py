# Python basis — theoriebundel
# Hoofdstuk 10 — Iteratie: while, for, range, break en continue
# 10.4 range: tellen zonder lijst

for i in range(5):
    print(i)


# Verwachte uitvoer:
# 0
# 1
# 2
# 3
# 4
