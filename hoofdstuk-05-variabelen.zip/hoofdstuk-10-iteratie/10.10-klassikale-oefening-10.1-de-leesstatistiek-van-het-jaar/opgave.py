# Python basis — theoriebundel
# Hoofdstuk 10 — Iteratie: while, for, range, break en continue
# Klassikale oefening 10.1 — De leesstatistiek van het jaar, opgave
#
# De situatie. De club heeft de bladzijden van de twaalf boeken van het voorbije jaar.
# Je maakt er een overzicht van.

bladzijden = [320, 180, 250, 410, 96, 512, 288, 175, 640, 205, 330, 148]
