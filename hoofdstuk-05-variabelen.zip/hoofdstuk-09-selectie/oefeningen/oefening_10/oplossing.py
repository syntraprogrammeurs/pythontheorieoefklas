# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 10 — Eenvoudige rekenmachine

getal1 = float(input("Eerste getal: "))
getal2 = float(input("Tweede getal: "))
bewerking = input("Bewerking: ")

match bewerking:
    case "+":
        print(f"Resultaat: {getal1 + getal2}")
    case "-":
        print(f"Resultaat: {getal1 - getal2}")
    case "*":
        print(f"Resultaat: {getal1 * getal2}")
    case "/":
        if getal2 == 0:
            print("Delen door nul is niet mogelijk.")
        else:
            print(f"Resultaat: {getal1 / getal2}")
    case _:
        print("Onbekende bewerking")


# Mogelijke uitvoer:
# Eerste getal: 10
# Tweede getal: 5
# Bewerking: *
# Resultaat: 50.0
