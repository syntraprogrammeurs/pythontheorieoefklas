# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 10 — Eenvoudige rekenmachine

# Vraag twee getallen.
# Vraag daarna welke bewerking uitgevoerd moet worden.
#
# Mogelijke bewerkingen:
# +
# -
# *
# /
#
# Gebruik match om de juiste berekening uit te voeren.
#
# Let op:
# delen door 0 mag niet.
# Als de gebruiker probeert te delen door 0, toon je:
# "Delen door nul is niet mogelijk."
#
# Bij een onbekende operator toon je:
# "Onbekende bewerking"
#
# Voorbeeld:
# Eerste getal: 10
# Tweede getal: 5
# Bewerking: *
# Resultaat: 50.0
