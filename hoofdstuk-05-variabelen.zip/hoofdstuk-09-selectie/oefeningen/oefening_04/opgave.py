# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 4 — Punten omzetten naar beoordeling

# Vraag een resultaat op 100.
#
# Toon:
# - minder dan 50: "Onvoldoende"
# - 50 tot en met 59: "Voldoende"
# - 60 tot en met 69: "Goed"
# - 70 tot en met 84: "Zeer goed"
# - 85 tot en met 100: "Uitstekend"
#
# Als het ingegeven resultaat kleiner is dan 0
# of groter is dan 100, toon je:
# "Ongeldig resultaat"
#
# Voorbeeld:
# Resultaat: 73
# Zeer goed
