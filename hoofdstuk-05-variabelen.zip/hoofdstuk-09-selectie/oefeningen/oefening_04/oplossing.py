# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 4 — Punten omzetten naar beoordeling

resultaat = int(input("Resultaat: "))

if resultaat < 0 or resultaat > 100:
    print("Ongeldig resultaat")
elif resultaat < 50:
    print("Onvoldoende")
elif resultaat < 60:
    print("Voldoende")
elif resultaat < 70:
    print("Goed")
elif resultaat < 85:
    print("Zeer goed")
else:
    print("Uitstekend")


# Mogelijke uitvoer:
# Resultaat: 73
# Zeer goed
