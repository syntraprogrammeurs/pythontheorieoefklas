# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 6 — Korting met geneste selectie

# Vraag de leeftijd van een klant.
# Vraag daarna of de klant een klantenkaart heeft.
# De gebruiker antwoordt met "ja" of "nee".
#
# Regels:
# - jonger dan 18 jaar: 20% korting
# - vanaf 18 jaar:
#     - met klantenkaart: 10% korting
#     - zonder klantenkaart: geen korting
#
# Gebruik hierbij een geneste if.
#
# Voorbeeld:
# Leeftijd: 35
# Klantenkaart (ja/nee): ja
# Je krijgt 10% korting.
