# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 6 — Korting met geneste selectie

leeftijd = int(input("Leeftijd: "))
klantenkaart = input("Klantenkaart (ja/nee): ").lower()

if leeftijd < 18:
    print("Je krijgt 20% korting.")
else:
    if klantenkaart == "ja":
        print("Je krijgt 10% korting.")
    else:
        print("Je krijgt geen korting.")


# Mogelijke uitvoer:
# Leeftijd: 35
# Klantenkaart (ja/nee): ja
# Je krijgt 10% korting.
