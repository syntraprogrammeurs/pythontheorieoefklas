# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 7 — Dag van de week met match

# Vraag een getal van 1 tot en met 7.
#
# Gebruik match om de dag van de week te tonen:
# 1 = maandag
# 2 = dinsdag
# 3 = woensdag
# 4 = donderdag
# 5 = vrijdag
# 6 = zaterdag
# 7 = zondag
#
# Bij een ander getal toon je:
# "Ongeldige dag"
#
# Voorbeeld:
# Geef een dagnummer: 4
# donderdag
