# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 7 — Dag van de week met match

dag = int(input("Geef een dagnummer: "))

match dag:
    case 1:
        print("maandag")
    case 2:
        print("dinsdag")
    case 3:
        print("woensdag")
    case 4:
        print("donderdag")
    case 5:
        print("vrijdag")
    case 6:
        print("zaterdag")
    case 7:
        print("zondag")
    case _:
        print("Ongeldige dag")


# Mogelijke uitvoer:
# Geef een dagnummer: 4
# donderdag
