# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 8 — Verkeerslicht met match

kleur = input("Kleur: ").lower()

match kleur:
    case "rood":
        print("Stoppen")
    case "oranje":
        print("Voorzichtig stoppen")
    case "groen":
        print("Doorrijden")
    case _:
        print("Onbekende kleur")


# Mogelijke uitvoer:
# Kleur: groen
# Doorrijden
