# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 8 — Verkeerslicht met match

# Vraag de kleur van een verkeerslicht.
#
# Mogelijke kleuren:
# rood
# oranje
# groen
#
# Gebruik match.
#
# Toon:
# rood    -> "Stoppen"
# oranje  -> "Voorzichtig stoppen"
# groen   -> "Doorrijden"
#
# Voor alle andere invoer toon je:
# "Onbekende kleur"
#
# Voorbeeld:
# Kleur: groen
# Doorrijden
