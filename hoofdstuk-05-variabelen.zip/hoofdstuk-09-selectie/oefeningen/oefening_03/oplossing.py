# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 3 — Leeftijdscategorie

leeftijd = int(input("Leeftijd: "))

if leeftijd < 12:
    print("Je bent een kind.")
elif leeftijd < 18:
    print("Je bent een tiener.")
else:
    print("Je bent een volwassene.")


# Mogelijke uitvoer:
# Leeftijd: 15
# Je bent een tiener.
