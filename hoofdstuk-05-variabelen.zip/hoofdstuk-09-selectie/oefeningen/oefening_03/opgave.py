# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 3 — Leeftijdscategorie

# Vraag de leeftijd van de gebruiker.
#
# Toon:
# - "kind" als de leeftijd kleiner is dan 12
# - "tiener" als de leeftijd van 12 tot en met 17 is
# - "volwassene" als de leeftijd 18 of ouder is
#
# Voorbeeld:
# Leeftijd: 15
# Je bent een tiener.
