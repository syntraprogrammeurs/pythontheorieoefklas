# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 5 — Toegang tot een attractie

leeftijd = int(input("Leeftijd: "))
lengte = int(input("Lengte: "))

if leeftijd >= 12 and lengte >= 140:
    print("Je mag op de attractie.")
else:
    print("Je mag niet op de attractie.")


# Mogelijke uitvoer:
# Leeftijd: 14
# Lengte: 145
# Je mag op de attractie.
