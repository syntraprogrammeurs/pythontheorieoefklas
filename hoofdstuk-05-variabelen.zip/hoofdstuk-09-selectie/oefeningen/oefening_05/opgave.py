# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 5 — Toegang tot een attractie

# Vraag de leeftijd en lengte in centimeter.
#
# Iemand mag op de attractie als:
# - hij of zij minstens 12 jaar oud is
# EN
# - minstens 140 cm groot is
#
# Toon:
# "Je mag op de attractie."
# of:
# "Je mag niet op de attractie."
#
# Voorbeeld:
# Leeftijd: 14
# Lengte: 145
# Je mag op de attractie.
