# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 2 — Even of oneven

getal = int(input("Geef een getal: "))

if getal % 2 == 0:
    print(f"{getal} is even.")
else:
    print(f"{getal} is oneven.")


# Mogelijke uitvoer:
# Geef een getal: 17
# 17 is oneven.
