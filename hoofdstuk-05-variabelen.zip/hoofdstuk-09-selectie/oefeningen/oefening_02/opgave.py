# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 2 — Even of oneven

# Vraag aan de gebruiker een geheel getal.
#
# Controleer of het getal even of oneven is.
#
# Een getal is even als de rest bij deling door 2 gelijk is aan 0.
#
# Voorbeeld:
# Geef een getal: 17
# 17 is oneven.
