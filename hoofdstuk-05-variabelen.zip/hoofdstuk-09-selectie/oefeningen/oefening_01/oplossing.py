# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 1 — Positief getal

getal = int(input("Geef een getal: "))

if getal > 0:
    print("Het getal is positief.")


# Mogelijke uitvoer:
# Geef een getal: 8
# Het getal is positief.
