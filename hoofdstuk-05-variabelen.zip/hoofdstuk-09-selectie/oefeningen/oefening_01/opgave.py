# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 1 — Positief getal

# Vraag aan de gebruiker een geheel getal.
# Als het getal groter is dan 0, toon je:
# "Het getal is positief."
#
# Als het getal 0 of negatief is, hoeft er niets te gebeuren.
#
# Voorbeeld:
# Geef een getal: 8
# Het getal is positief.
