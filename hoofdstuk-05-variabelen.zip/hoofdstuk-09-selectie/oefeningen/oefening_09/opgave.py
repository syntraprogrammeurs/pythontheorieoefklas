# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oefening 9 — Weekend of werkdag

# Vraag de naam van een dag.
#
# Gebruik match.
#
# Voor maandag, dinsdag, woensdag, donderdag en vrijdag:
# "Het is een werkdag."
#
# Voor zaterdag en zondag:
# "Het is weekend."
#
# Gebruik meerdere waarden binnen één case waar mogelijk.
#
# Voor een onbekende dag toon je:
# "Ongeldige dag"
#
# Voorbeeld:
# Dag: zaterdag
# Het is weekend.
