# Python basis — theoriebundel
# Hoofdstuk 9 — Selectie: if, elif, else en match
# Oplossing 9 — Weekend of werkdag

dag = input("Dag: ").lower()

match dag:
    case "maandag" | "dinsdag" | "woensdag" | "donderdag" | "vrijdag":
        print("Het is een werkdag.")
    case "zaterdag" | "zondag":
        print("Het is weekend.")
    case _:
        print("Ongeldige dag")


# Mogelijke uitvoer:
# Dag: zaterdag
# Het is weekend.
